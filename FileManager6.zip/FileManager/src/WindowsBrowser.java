/**
 * @author Oved Shalem 27119684
 *
 */

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
 public class WindowsBrowser
 {
    public static void main( String args[] )
    {
    	Browser br = new Browser();
    	br.setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );
    	br.setSize( 800, 600 ); // set frame size
    	br.setVisible( true ); // display frame
    	br.setTitle("File Manager");
    } 
 } 
