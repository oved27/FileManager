
/**
 * @author Oved Shalem 27119684
 *
 */

import java.awt.BorderLayout;
import java.awt.GridLayout;
import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;
import java.awt.event.ActionEvent;

public class Browser extends JFrame {
	//Declaration 
	final JPanel panel = new JPanel();				//Massage panel
	private JLabel source;
	private JLabel destination;
	
	//Button Declaration
	private JButton btnBackUp;
	private JButton btnRestore;
	private JButton btnDelete;
	private JButton btnAddFile;
	private JButton btnRename;

	private String path;
	private JList DisplayListSource;
	private JList DisplayListDestination;
	
	private JTextField inputSourceBox;
	private JTextField destinationBox;
	private DefaultListModel listSource;
	private DefaultListModel listDestination;
	private JScrollPane scrolSource;
	private JScrollPane scrollDest;
	private File isFileExist;
	private File origenalFile;
	private File fileToMove;
	private File backupFile;
	
	//Set source and destination deceleration
	final  String sourceFolder = new String ("c:\\source");
	final  String destinationFolder = new String ("c:\\Temp");

	public Browser() {

		JPanel MasterPanel = new JPanel(new BorderLayout());			//Master panel
		JPanel titlePanel = new JPanel(new GridLayout(2, 1));			//Master title
		JPanel DetailsPanel = new JPanel(new GridLayout(2, 2));			//List path panels
		JPanel listPanel = new JPanel(new GridLayout(1, 2));			//Lists panels
		JPanel leftPanel = new JPanel(new GridLayout(1, 1));			//Left panel 
		JPanel rightPanel = new JPanel(new GridLayout(1, 1));			//Right panel
		JPanel bottonPanel = new JPanel(new GridLayout(1, 5));			//Button panel

		MasterPanel.add(titlePanel, BorderLayout.NORTH);				//Add title to master panel

		MasterPanel.add(listPanel, BorderLayout.CENTER);				//Add list panel to master panel
		MasterPanel.add(bottonPanel, BorderLayout.SOUTH);				//Add button to master panel

		titlePanel.add(new JLabel("File & Directory Manager", JLabel.CENTER));	//Add title to title panel
		titlePanel.add(DetailsPanel);									//Add details to title panel
		DetailsPanel.add(new JLabel("Source", JLabel.CENTER));			//Add title to left source panel
		DetailsPanel.add(new JLabel("Destination", JLabel.CENTER));		//Add title to right destination panel
		inputSourceBox = new JTextField(255); 							//Path for input source folder
		inputSourceBox.setToolTipText("Source");						//Tooltip for source folder
		inputSourceBox.setText(sourceFolder);							//Display the source folder
		FileOptions.getInstance().setDirName(new File(sourceFolder));	//Set the source folder

		destinationBox = new JTextField(255);							//Path for input source folder destination
		destinationBox.setToolTipText("destination");					//Tooltip for Destination folder
		destinationBox.setEditable(false);								//Disable edit the destination pane 
		destinationBox.setText(destinationFolder);						//Display the Destination folder
		DetailsPanel.add(inputSourceBox);								//Add source box to panel	
		DetailsPanel.add(destinationBox);								//Add destination box to panel

		DisplayListSource = new JList();								//Source list 
		DisplayListDestination = new JList();							//Destination list
		listSource = FileOptions.getInstance().folderList(sourceFolder);//Add the source list
		listDestination = FileOptions.getInstance().folderList(destinationFolder); //Add the destination list

		scrolSource = new JScrollPane(DisplayListSource);				//Add scroll to source list 
		scrollDest = new JScrollPane(DisplayListDestination);			//Add scroll to Destination list

		DisplayListSource.setModel(listSource);							//Set list source model to the display
		DisplayListSource.setToolTipText("DisplayListSource");			//Tooltip for source list folder
		DisplayListDestination.setModel(listDestination);				//Set list destination model to the display

		listPanel.add(leftPanel);										//Add source panel to listPanel
		listPanel.add(rightPanel);										//Add destination panel to listPanel
		leftPanel.add(scrolSource);										//Add scroll to  source left panel 
		rightPanel.add(scrollDest);										//Add scroll to  destination right panel 

		//Operation buttons
		btnBackUp = new JButton("Backup");
		btnRestore = new JButton("Restore");
		btnDelete = new JButton("Delete");
		btnAddFile = new JButton("Add");
		btnRename = new JButton("Rename");

		//Add button to button panel
		bottonPanel.add(btnBackUp);
		bottonPanel.add(btnRestore);
		bottonPanel.add(btnDelete);
		bottonPanel.add(btnAddFile);
		bottonPanel.add(btnRename);
		//Add the master panel
		add(MasterPanel);

		//Listener to source path input
		TextFieldListener pathListener = new TextFieldListener();
		inputSourceBox.addActionListener(pathListener);
		
		//Button handler to press button
		ButtonHandler handler = new ButtonHandler();
		
		//Add button to action listener
		btnBackUp.addActionListener(handler);
		btnRestore.addActionListener(handler);
		btnDelete.addActionListener(handler);
		btnAddFile.addActionListener(handler);
		btnRename.addActionListener(handler);

	}
	//Method for handle button events 
	private class ButtonHandler implements ActionListener {
		public void actionPerformed(ActionEvent event) {
			//Case backup button was pressed
			if (event.getSource() == btnBackUp) {
				//Case no file was choose
				if (DisplayListSource.getSelectedValue() != null) {			
					//
					backupFile = new File(FileOptions.getInstance().getDestFolderToBackup() + "\\"
					+ DisplayListSource.getSelectedValue().toString()+ ".BACK" );
					origenalFile = new File(FileOptions.getInstance().getDirName() + "\\"
							+ DisplayListSource.getSelectedValue().toString());
					File fileToBackUp = new File(FileOptions.getInstance().getDirName() + "\\"
							+ DisplayListSource.getSelectedValue().toString());
					//Case the file is exist in backup folder 
					if (!backupFile.exists()) {
						
						FileOptions.getInstance().backUpFile(fileToBackUp);
						errorMassege("File Backup");
					} 
					//If file exist check if you want to overwrite
					else if(FileOptions.getInstance().checkIfOverWrite(origenalFile,backupFile)){
						
						FileOptions.getInstance().backUpFile(fileToBackUp);
						errorMassege("File Backup");
						}
					//If choose not to overwrite
					else{
						errorMassege("You select not to overwrite the backup file");
					}
					//Case button press with no file selection
				} else {
					errorMassege("You didn't select file. Please select file from left pane");

				}
				refreshView();			//Refresh the new view at the end of event
			} 
			//Case restore button was pressed
			else if (event.getSource() == btnRestore) {
				//Case no file was choose
				if (DisplayListDestination.getSelectedValue() != null) {
					
					backupFile = new File(FileOptions.getInstance().getDestFolderToBackup() + "\\"
							+ DisplayListDestination.getSelectedValue());
					origenalFile = new File(FileOptions.getInstance().getDirName() + "\\"
							+ DisplayListDestination.getSelectedValue().toString().replace(".BACK", ""));
					fileToMove = new File(FileOptions.getInstance().getDestFolderToBackup() + "\\"
							+ DisplayListDestination.getSelectedValue().toString());
					//Case the file is exist in s folder 
					if(!origenalFile.exists()){
						FileOptions.getInstance().restoreFile(fileToMove);
						errorMassege("File restored");
					}
					//If file exist check if you want to overwrite
					else if(FileOptions.getInstance().checkIfOverWrite(origenalFile,backupFile)){
						FileOptions.getInstance().restoreFile(fileToMove);
						errorMassege("File restored");
					}
					//If choose not to overwrite
					else{
						errorMassege("You choose not to overwrite");
					}
				}
				//Case button press with no file selection
				else {
					errorMassege("You didn't select file. Please select file from left pane");
				}
				refreshView();					//Refresh the view
				}
			//Case delete button was pressed
			 else if (event.getSource() == btnDelete) {
				//Case no file was choose
				if (DisplayListSource.getSelectedValue() != null) {
					
					File fileToDelete = new File(FileOptions.getInstance().getDirName() + "\\"
							+ DisplayListSource.getSelectedValue().toString());
						//Ask user for confirm deletion file  
					try {
						int dialogButton = JOptionPane.YES_NO_OPTION;
						int dialogResult = JOptionPane.showConfirmDialog(panel,
								"Delete file?", "Warning", dialogButton);
						//Case filer can be delete
						if (dialogResult == JOptionPane.YES_OPTION) {
							FileOptions.getInstance().deleteFile(fileToDelete);
							errorMassege("File delete succes.");
						}
						//Case choose no
						else{
							errorMassege("Action cancel by the user.");
						}

					} catch (IOException e) {

						e.printStackTrace();
					}
					//Case button press with no file selection
				} else {
					errorMassege("You didn't select file. Please select file from left pane");
				}
				refreshView();					//Refresh the view
				//Case Add button was pressed
			} else if (event.getSource() == btnAddFile) {
				//Create the selection file box to add
				JFileChooser fileChooser = new JFileChooser();
				fileChooser.setCurrentDirectory(new File(sourceFolder));
				int result = fileChooser.showOpenDialog(null);
				if (result == JFileChooser.APPROVE_OPTION) { // user selects a
																// file
					File fileToAdd = fileChooser.getSelectedFile();
					//Case the selection folder is the backup folder
					if(FileOptions.getInstance().getDestFolderToBackup().equalsIgnoreCase(fileToAdd.getParentFile().toString())){
						errorMassege("Can't add to backup folder");
					}
					else{//Add the file to the folder
						FileOptions.getInstance().addFile(fileToAdd);
					}
				}
				refreshView();					//Refresh the view
				//Case rename button was pressed
			} else if (event.getSource() == btnRename) {
				//Case no file was choose
				if (DisplayListSource.getSelectedValue() != null) {
					//Get the full path of the file
					File fileToRename = new File(FileOptions.getInstance().getDirName() + "\\"
							+ DisplayListSource.getSelectedValue().toString());
					//Send the file to rename
					FileOptions.getInstance().reNameFile(fileToRename);

				} 
				else {							//Case no file select
					errorMassege("You didn't select file. Please select file from left pane");
			}
				refreshView();					//Refresh the view
			}
		}
	}
	//Method for error massage
	private void errorMassege(String msg){
		JOptionPane.showMessageDialog(panel, msg, "Error", JOptionPane.ERROR_MESSAGE);
	}
	//Method for information massage
	private void InformationMassege(String msg){
		JOptionPane.showMessageDialog(panel,msg);
		}
	//Method for refresh the list files
	private void refreshView() {
		//Export the source list
		listSource = FileOptions.getInstance().folderList(FileOptions.getInstance().getDirName().getPath());
		//Export the destination list
		listDestination = FileOptions.getInstance().folderList(destinationFolder);
		//Display the source list 
		DisplayListSource.setModel(listSource);
		//Display the destination list
		DisplayListDestination.setModel(listDestination);
	}
	//Method for handle source path 
	private class TextFieldListener implements ActionListener {
		public void actionPerformed(ActionEvent event) {
			if (event.getSource() == inputSourceBox) {			//Case valid path enter
				if (FileOptions.getInstance().checkDirectory(inputSourceBox.getText())) {
					FileOptions.getInstance().setDirName(new File(inputSourceBox.getText()));
					InformationMassege("Path has change");
					refreshView();								//Refresh the view
				} else {										//Case invalid path enter
					errorMassege("Path is Invalid");
					FileOptions.getInstance().setDirName(new File(sourceFolder));	//Return to default folder
					inputSourceBox.setText(sourceFolder);
					refreshView();								//Refresh the view
				}
			}
		}
	}
}
