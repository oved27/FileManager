/**
 * @author Oved Shalem 27119684
 *
 */

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import javax.swing.DefaultListModel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

public class FileOptions {
	private File dirName;										//Hold the parent directory
	private static FileOptions instance = null;					//Use for single tone
	private String DestFolderToBackup = "c:\\Temp";				//Hold the backup folder path
	final JPanel panel = new JPanel();							//Jpanel for popup massages

	// create single tone for file options
	public static FileOptions getInstance() {
		//Case instance is empty
		if (instance == null) {
			instance = new FileOptions();
		}
		return instance;
	}
	//Method for get the destination folder
	public String getDestFolderToBackup(){
		return DestFolderToBackup;
	}
	//Getter for directory name
	public File getDirName() {
		return dirName;
	}
	//Setter for directory name
	public void setDirName(File dirName) {
		this.dirName = dirName;
	}
	//Method for check if the item selected is file or directory
	public boolean checkDirectory(String path) {
		File pathToCheck = new File(path);
		//Case is a directory
		if (pathToCheck.isDirectory()) {
			return true;
		} else {							//Case it's file
			return false;
		}
	}
	//Method for return the list folder
	public DefaultListModel folderList(String path) {
		File pathToCheck = new File(path);							//Use the path to create an object
		DefaultListModel folderList = new DefaultListModel();		

		File directory[] = pathToCheck.listFiles();					//Create a list of files in the directory 

		for (File directoryName : directory) {
			if(directoryName.isDirectory() == false){
			folderList.addElement(directoryName.getName()); 		//add directory file item to the list
			}														//source list
		}
		return folderList;											//Return the folder list
	}

	//Method for check if overwrite
	public boolean checkIfOverWrite(File originaleFile , File backUpFile){
		long origenalFileDate = originaleFile.lastModified();		//Get last modified date of source file
		long backupFileDate = backUpFile.lastModified();			//Get last modified date of destination file
		
		if (origenalFileDate < backupFileDate) {					//Case source is newer
			if(askUserToOverWirte("Source file is older. Would you like to overwrite new file?")){
				return true;	
			}
			else{													//Case user decided not to overwrite
				return false;
			}
		} 
		else {														//Case source is older
			if(askUserToOverWirte("Source file is newer. Would you like to overwrite new file?")){
				return true;
			}
			else{													//Case user decided not to overwrite
				return false;
				}
			}	
		}
	//Method for create yes/no dialogbox for delete file
	public boolean askUserToOverWirte(String msg){
		int dialogButton = JOptionPane.YES_NO_OPTION;
		int dialogResult = JOptionPane.showConfirmDialog(panel,msg, "Warning", dialogButton);
		if (dialogResult == JOptionPane.YES_OPTION) {				//Case yes
			return true;
		}
		else{														//Case No
			return false;
		}	
	}
	//Method for backup the file
	public void backUpFile(File source){
			try {
				copyFileUsingStream(source, new File(DestFolderToBackup + "\\" + source.getName() + ".BACK"));
			} catch (IOException e) {
				e.printStackTrace();
			}
	}
	//Method for restore the file
	public void restoreFile(File source){
		try {
			
			if(getDirName() + "\\" + source.getName().endsWith(".BACK") != null){
				copyFileUsingStream(source, new File(getDirName() + "\\" + source.getName().substring(0,source.getName().length()-5)));
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	//Method for delete file
	public void deleteFile(File source) throws IOException{
		source.delete();
}
	public void reNameFile(File source){
		try {
			String newFileName= JOptionPane.showInputDialog("Please insert new file name:");
			if(!newFileName.isEmpty()){
				copyFileUsingStream(source, new File(getDirName() + "\\" + newFileName));
			}
			deleteFile(source);
		} catch (IOException e) {
			e.printStackTrace();
		}
}
	//Method for add a file
	public void addFile(File source){
		try {
			copyFileUsingStream(source, new File(getDirName() + "\\" + source.getName()));
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	//Method for copy file using streaming
	private void copyFileUsingStream(File source, File dest)
			throws IOException {
		InputStream is = null;
		OutputStream os = null;
		try {
			is = new FileInputStream(source);
			os = new FileOutputStream(dest);
			byte[] buffer = new byte[1024];
			int length;
			while ((length = is.read(buffer)) > 0) {
				os.write(buffer, 0, length);
			}
		} finally {
			is.close();
			os.close();
		}
	}
}
